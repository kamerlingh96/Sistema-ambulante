<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Respaldo extends CI_Controller{



  function index()
  {
    if ($this->session->userdata('login')) {

    		header ("Location: ".base_url()."uploads/respaldo.php"); // Redireccionamos para descargar el Arcivo ZIP


    }else {
      $data = array('title' => 'Login');
      $this->load->view("login/Login" , $data);
    }
  }



}
