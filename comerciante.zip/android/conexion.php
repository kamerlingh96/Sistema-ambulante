<?php

/*$hostname='[::1]';
$database='ambulante';
$username='sistemaambulantes';
$password='gobambu19';*/

/*$hostname='localhost';
$database='comerciantes';
$username='root';
$password='';*/

$hostname='localhost';
$database='corpboxc_comerciantes';
$username="corpboxc_kamerli';
$password='Subsuelo10@';

$conexion = new mysqli($hostname,$username,$password,$database);
if ($conexion->connect_errno) {
  echo "No se pudo conectar a la base de datos";
}


 ?>
